package com.raven.event;

public interface EventChat {

    public void sendMessage(String text);
}
